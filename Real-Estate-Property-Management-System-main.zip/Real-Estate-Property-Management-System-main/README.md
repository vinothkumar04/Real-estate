# Real Estate Property Management System

A comprehensive CRM architecture built on Salesforce to streamline property listings, lease lifecycles, tenant onboarding, and automated maintenance routing.

## Tech Stack
* **Frontend:** Lightning Web Components (LWC), Aura, SLDS
* **Backend:** Apex (Triggers, Batch, Schedulable), SOQL (Aggregate, Parent-Child)
* **Automation:** Screen Flows, Record-Triggered Flows
* **Analytics:** Salesforce Reports & Dashboards

---

## Key Implementations

### Database & UI Customization
* **Schema Design:** Built a relational model tracking `Properties`, `Tenants`, `Lease Agreements`, `Vendors`, and `Maintenance Cases`.
* **Button Override:** Overrode the standard "New" button via an Aura Component (`lightning:actionOverride`) to launch a custom Screen Flow.
* **File Validation:** Configured a strict validation loop using a Flow Decision Element to block property creation until a property image is attached.

### Frontend Engineering (LWC)
* **Dynamic Search Interface:** Developed a responsive LWC using SLDS Grids for real-time property filtering by rent, availability, and furnishing status.
* **Server-Side Pagination:** Optimized performance using an Apex controller with SOQL `LIMIT` and `OFFSET` to stream data in batches of 25 records.
* **JS Data Manipulation:** Used JavaScript Getters and `.map()` to dynamically calculate row serial numbers (`sNo`) and inject clickable record URLs.

### Backend Automation & Apex Logic
* **Task Automation:** Wrote an Apex Trigger handler to automatically generate and assign onboarding task checklists to staff upon tenant allocation.
* **Intelligent Routing Algorithm:** Coded a Maintenance Trigger using an Aggregate SOQL query to count open cases per vendor, programmatically routing new requests to the vendor with the lowest active workload.
* **Asynchronous Alert Engine:** Programmed Batch and Schedulable Apex to scan records daily and automatically email tenants exactly 30 days prior to lease expiration.

### Reports & Dashboards
* **Executive Analytics:** Built Tabular, Summary, and Matrix reports with dashboards to track *Expiring Leases*, *Maintenance Statuses*, and *Property Occupancy Rates*.
