({
    doInit : function (component, event, helper) 
    {
        var flow = component.find("flowData");
        flow.startFlow("Create_Property_Wizard");
    },
    
    // This new function handles the Finish button!
    handleStatusChange : function (component, event) 
    {
        if(event.getParam("status") === "FINISHED") 
        {
            var outputVariables = event.getParam("outputVariables");
            var newRecordId;
            
            // Find the ID we output from the Flow
            if(outputVariables) 
            {
                for(var i = 0; i < outputVariables.length; i++) 
                {
                    if(outputVariables[i].name === "var_NewPropertyId") 
                    {
                        newRecordId = outputVariables[i].value;
                        break;
                    }
                }
            }
            
            // Redirect to the newly created Property Record
            if(newRecordId) 
            {
                var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                    "recordId": newRecordId,
                    "slideDevName": "detail"
                });
                navEvt.fire();
            } 
            else 
            {
                // If something goes wrong, fall back to the Property List View
                var navHome = $A.get("e.force:navigateToObjectHome");
                navHome.setParams({
                    "scope": "Property__c"
                });
                navHome.fire();
            }
        }
    }
})