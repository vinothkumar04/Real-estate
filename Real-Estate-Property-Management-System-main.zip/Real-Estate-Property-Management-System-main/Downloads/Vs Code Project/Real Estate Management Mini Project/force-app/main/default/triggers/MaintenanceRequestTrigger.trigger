trigger MaintenanceRequestTrigger on Maintenance_Request__c (before insert) 
{
    switch on Trigger.operationType 
    {   
        when BEFORE_INSERT 
        {
            MaintenanceRequestHandler.handleBeforeInsert(Trigger.new);
        }
        
    }
}