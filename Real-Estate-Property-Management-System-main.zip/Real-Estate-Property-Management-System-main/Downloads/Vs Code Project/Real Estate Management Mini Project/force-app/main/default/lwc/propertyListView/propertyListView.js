import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getProperties from '@salesforce/apex/PropertyController.getProperties';

export default class PropertyList extends NavigationMixin(LightningElement) {

    @track maxRent              = null;
    @track selectedAvailability = '';
    @track selectedFurnishing   = '';

    @track properties   = [];
    @track totalRecords = 0;
    @track totalPages   = 1;
    @track currentPage  = 1;
    pageSize = 25;

    @track isLoading    = false;
    @track errorMessage = '';
    @track hasSearched  = false;

    // TABLE COLUMNS
    columns = [
        { 
            label: 'S.No', 
            fieldName: 'sNo', 
            type: 'number', 
            initialWidth: 70,
            cellAttributes: { alignment: 'left' }
        },
        { 
            label: 'Property Name', 
            fieldName: 'propertyUrl',
            type: 'url',
            typeAttributes: {
                label: { fieldName: 'Name' }
            },
        },
        { 
            label: 'City',
            fieldName: 'City__c',
            type: 'text',
        },
        { 
            label: 'District',
            fieldName: 'District__c',
            type: 'text',
        },
        { 
            label: 'State',
            fieldName: 'State__c',
            type: 'text',

        },
        { 
            label: 'Rent',          
            fieldName: 'Rent__c',              
            type: 'currency',
            typeAttributes: { currencyCode: 'INR' },
            cellAttributes: { alignment: 'left' },
        },
        { 
            label: 'Availability',  
            fieldName: 'Status__c',            
            type: 'text',
        },
        { 
            label: 'Furnishing',    
            fieldName: 'Furnishing_Status__c', 
            type: 'text',
        }
    ];

    //DROPDOWN OPTIONS
    availabilityOptions = [
        { label: '-- Select --', value: ''          },
        { label: 'Available',    value: 'Available' },
        { label: 'Occupied',     value: 'Occupied'  }
    ];

    furnishingOptions = [
        { label: '-- Select --',   value: ''               },
        { label: 'Furnished',      value: 'Furnished'      },
        { label: 'Semi-Furnished', value: 'Semi-Furnished' },
        { label: 'Unfurnished',    value: 'Unfurnished'    }
    ];

    //  LOAD DATA FROM APEX 
    loadProperties() {
        this.isLoading    = true;
        this.errorMessage = '';

        getProperties({
            maxRent:      this.maxRent,
            availability: this.selectedAvailability,
            furnishing:   this.selectedFurnishing,
            pageNumber:   this.currentPage,
            pageSize:     this.pageSize
        })
        .then(result => {
            // Add S.No and propertyUrl for navigation
            let startNumber = (this.currentPage - 1) * this.pageSize + 1;
            this.properties = result.properties.map((prop, index) => {
                return { 
                    ...prop, 
                    sNo: startNumber + index,
                    propertyUrl: `/lightning/r/Property__c/${prop.Id}/view`
                };
            });

            this.totalRecords = result.totalRecords;
            this.totalPages   = result.totalPages;
            this.isLoading    = false;
        })
        .catch(error => {
            this.errorMessage = error.body ? error.body.message : error.message;
            this.isLoading    = false;
        });
    }

    //  FILTER CHANGE HANDLERS 
    handleMaxRentChange(event) {
        this.maxRent = event.target.value ? parseFloat(event.target.value) : null;
    }

    handleAvailabilityChange(event) {
        this.selectedAvailability = event.detail.value;
    }

    handleFurnishingChange(event) {
        this.selectedFurnishing = event.detail.value;
    }

    //  SEARCH — all 3 fields required 
    handleSearch() {

        // Field 1: Max Rent Price is required
        if (!this.maxRent || this.maxRent <= 0) {
            this.errorMessage = 'Please enter Max Rent Price.';
            return;
        }

        // Field 2: Availability Status is required
        if (!this.selectedAvailability) {
            this.errorMessage = 'Please select an Availability Status.';
            return;
        }

        // Field 3: Furnishing Status is required
        if (!this.selectedFurnishing) {
            this.errorMessage = 'Please select a Furnishing Status.';
            return;
        }

        // All 3 filled — run search
        this.errorMessage = '';
        this.hasSearched  = true;
        this.currentPage  = 1;
        this.loadProperties();
    }

    //  PAGINATION 
    handlePrevious() {
        if (this.currentPage > 1) {
            this.currentPage -= 1;
            this.loadProperties();
        }
    }

    handleNext() {
        if (this.currentPage < this.totalPages) {
            this.currentPage += 1;
            this.loadProperties();
        }
    }

    //  COMPUTED PROPERTIES used in HTML 
    get noRecords()  { return this.hasSearched && this.properties.length === 0; }
    get isFirstPage(){ return this.currentPage === 1; }
    get isLastPage() { return this.currentPage >= this.totalPages; }
    get showTable()  { return this.hasSearched && this.properties.length > 0; }
}