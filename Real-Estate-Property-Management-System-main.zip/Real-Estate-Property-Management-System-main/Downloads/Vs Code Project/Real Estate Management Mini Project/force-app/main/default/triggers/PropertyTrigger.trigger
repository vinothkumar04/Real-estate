trigger PropertyTrigger on Property__c (after insert, after update) 
{    
    switch on Trigger.operationType 
    {
        when AFTER_INSERT 
        {
            PropertyTriggerHandler.handleAfterInsert(Trigger.new);
        }
        
        when AFTER_UPDATE 
        {
            PropertyTriggerHandler.handleAfterUpdate(Trigger.new, Trigger.oldMap);
        }
    }
}