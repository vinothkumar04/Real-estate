trigger LeaseAgreementTrigger on Lease_Agreement__c (before insert, before update) 
{    
    switch on Trigger.operationType 
    {
        when BEFORE_INSERT 
        {
            LeaseAgreementTriggerHandler.handleBeforeInsert(Trigger.new);
        }
        
        when BEFORE_UPDATE 
        {
            LeaseAgreementTriggerHandler.handleBeforeUpdate(Trigger.new, Trigger.oldMap);
        }
    }
}